# SterCore 
SterCore posílá zprávy přes kabely. Většinou jde o síťové kabely. Internetové zatím neumí. Snad se naučí obrázky. A soubory. A možná něco navíc. Pokud z toho do maturity nezcvoknu.

## Co to umí? :thinking:
- Poslat zprávu
- Ukázat zprávu
- Udržet připojení
- Nezničit počítač
- Vypadat hezky
- Vytvořit světový mír

Jedna z těch věcí je lež. Neřeknu jaká. Na to musíte přijít sami.

## Jak to mám spustit? :thinking:
Stačí zajít do Releases. Jsou tam snad různý verze. Někde tam jsou rary. Stačí to rozbalit. Pak nechat 10 minut podusit při 200°C. Potom stačí instalovat. A je hotovo.

Pokud jste líní či neschopní, je to [TADY](https://github.com/tehSIRius/SterCore/releases). Vše potřebné je v .rar souborech. Source code je více méně k ničemu. Pokud nechcete přijít o rozum.

## Jak to chutná? :thinking:

Nejlepší přirovnání jsou nejlevnější brambůrky z Kauflandu. Čtyři týdny prošlé. Ponechané na slunci. A větru. Dalších čtrnáct dní.

## Ty ikonky vypadají hezky. Kde je seženu? :thinking:

Dělali je kluci a holky z [icons8.com](https://icons8.com/). To já neumím.
