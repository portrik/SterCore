Prostě s tím nedělejte blbosti.
